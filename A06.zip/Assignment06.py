# ------------------------------------------------------------------------------------------ #
# Title: Assignment06.py
# Desc: This assignment demonstrates using functions
# with structured error handling
# Change Log: (Who, When, What)
# J. Huminski, 11/18/2024, Created Script
# J. Huminski, 11/19/2024, Created Functions
# ------------------------------------------------------------------------------------------ #
import json

# ---------- Data ----------

# Constants:
MENU: str = ("---Course Registration Program---\n"
             "Select from the following menu:\n"
             "1. Register a student for the course\n"
             "2. Show current data\n"
             "3. Save data to a file\n"
             "4. Exit the program\n"
             "----------------------------------")
FILE_NAME: str = "Enrollments.json"

# Variables:
students: list = []
message: str = ""

# ---------- Processing ----------
class FileProcessor:
    """
    This is a collection of processing functions that will work with reading, and writing to JSON files

    ChangeLog:
    J. Huminski // 11.19.2024 // Created Class
    J. Huminski // 11.19.2024 // Added function "read_data_from_file" to access and load data into program
    J. Huminski // 11.19.2024 // Added function "write_data_to_file" to save data gathered from user input to JSON file
    J. Huminski // 11.20.2024 // Finalized code for "read_data_from_file" function.
    J. Huminski // 11.20.2024 // Finalized code for "write_data_to_file" function that saves data to JSON
    """

    @staticmethod
    def read_data_from_file(file_name: str, student_data: list):
        """
        This function reads data stored in a JSON file
        and loads it into the program for user access.

        ChangeLog:
        J. Huminski // 11.19.2024 // Created Function
        J. Huminski // 11.20.2024 // Wrote code to successfully read file data
        """

        try:
            file = open(file_name, "r")
            student_data = json.load(file)
            file.close()
        except FileNotFoundError as e:
            IO.output_error_messages("This file must exist prior to running this program", e)
            exit()
        except Exception as e:
            IO.output_error_messages("There was a non-specific error!", e)
            exit()
        finally:
            if not file.closed:
                file.close()
        return student_data

    @staticmethod
    def write_data_to_file(file_name: str, student_data:list, message:str):
        """This function will collect user input
        and save it to a JSON file.

        ChangeLog:
        J. Huminski // 11.19.2024 // Created Function
        J. Huminski // 11.20.2024 // Wrote code to successfully write data to a JSON file.
        """
        try:
            file = open(file_name, "w")
            json.dump(student_data, file, indent=4)
            file.close()
        except FileNotFoundError as e:
            IO.output_error_messages("There was a problem saving your data. Please contact support", e)
        except PermissionError as e:
            IO.output_error_messages("ERROR: Unable to write to file. "
                                     "This may be because the file is read-only.", e)
        except TypeError as e:
            IO.output_error_messages("ERROR: Incorrect type", e)

        except Exception as e:
            IO.output_error_messages("There was a non-specific error!", e)
        finally:
            if not file.closed:
                file.close()
        for student in student_data:
            print("-" * 50)
            message = (f"{student['FirstName']} {student['LastName']}'s data has been recorded."
                        f" They have enrolled in: {student['CourseName']}.")
            print("-" * 50)
            print(message)

# ---------- Presentation ----------
class IO:
    """
    A collection of presentation layer functions that manage user input and output.
    
    ChangeLog:
    J. Huminski // 11.19.2024 // Created Class
    J. Huminski // 11.19.2024 // Created output_error_messages function to display error code to user
    J. Huminski // 11.20.2024 // Created output_menu function to display options to user
    J. Huminski // 11.20.2024 // Finalized code for "output_error_messages" function.
    J. Huminski // 11.20.2024 // Finalized code to display menu to user
    """

    @staticmethod
    def output_error_messages(message: str, error: Exception = None):
        """
        This function displays a custom error message to the user.

        ChangeLog:
        J. Huminski // 11.19.2024 // Created Function
        J Huminski // 11.20.2024 // Finalized error handling code
        """
        print(message, end="\n\n")
        if error is not None:
            print ("-- Technical Error Message --")
            print(error, error.__doc__, type(error), sep='\n')

    @staticmethod
    def output_menu(menu: str):
        """This function displays a menu of options for the user to choose from.

        ChangeLog:
        J. Huminski // 11.20.2024 // Created Function & finalized code for displaying menu of option to user.
        """
        print()
        print(menu)
        print()

    @staticmethod
    def handle_menu_choice(menu_choice: str):
        """
        This function collects the menu choice from the user and designates a function dependent on user input.

        ChangeLog:
        J. Huminski // 11.20.2024 // Created Function, changed named to "handle_menu_choice",
        finalized code to user input

        :return: function dependent on user's input (menu_choice)
        """

        match menu_choice:
            case "1":
                IO.input_student_data(student_data=students)
            case "2":
                IO.output_student_courses(student_data=students, message=message)
            case "3":
                FileProcessor.write_data_to_file(file_name=FILE_NAME, student_data=students, message=message)
            case "4":
                print("\nThank you for using the Course Registration Program.\n"
                      "You have exited the program")
                exit()
            case _:
                print("ERROR: Please choose a correct choice from the menu of options")

                return menu_choice



    @staticmethod
    def output_student_courses(student_data: list, message: str):
        """This function will display the collected data to the user when prompted.

        ChangeLog:
        J. Huminski // 11.20.2024 // Created Function, Finalized code to display collected data to user
        """
        print()
        print("-" * 50)
        for student in student_data:
            message = (f"Student {student['FirstName']} {student['LastName']} "
                       f"has enrolled in {student['CourseName']}.")
            print(message)
        print("-" * 50)
        print()

    @staticmethod
    def input_student_data(student_data: list):
        """This function will collect data from the user and add it to the list of previously
        collected data

        ChangeLog:
        J. Huminski // 11.20.2024 // Created Function, Finalized code for collecting user input.
        """
        while True: # Nested while loop to repeat if error occurs.
            try:
                student_first_name = input("What is the student's first name? ")
                print()
                if not student_first_name.isalpha():
                    raise ValueError("The first name cannot contain numbers.")
                break # Will only break if ValueError is not raised
            except ValueError as e:
                print()
                print(e)
                print()

        while True: # Nested while loop to repeat if error occurs.
            try:
                student_last_name = input("What is the student's last name? ")
                print()
                if not student_last_name.isalpha():
                    raise ValueError("The last name cannot contain numbers.")
                break # Will only break if ValueError is not raised
            except ValueError as e:
                print()
                print(e)
                print()

        course_name = input("Please enter the course you wish to enroll in: ")
        print()

        student = {"FirstName": student_first_name,
                        "LastName": student_last_name,
                        "CourseName": course_name}

        print(f"Thank you, {student_first_name} {student_last_name}! "
              f"You have successfully registered for {course_name}")

        student_data.append(student)

        return student_data




# --------------------- END OF FUNCTION DEFINITIONS ---------------------

# --------------------- MAIN BODY ---------------------
students = FileProcessor.read_data_from_file(file_name = FILE_NAME, student_data=students)

while True:
    IO.output_menu(MENU)

    menu_choice = input("Please enter your choice from the menu of options above: ")
    IO.handle_menu_choice(menu_choice)